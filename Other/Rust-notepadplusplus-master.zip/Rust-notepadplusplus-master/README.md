Rust-syntax file for notepad++
==============================

Notepad++ syntax highlighting for Rust.

Use: 
* Download userDefineLang_rust.xml
* In Notepad++ open Language -> define your own language
* use Import to add Rust syntax highlighting to files with .rs extension 
